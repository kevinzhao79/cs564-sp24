SELECT COUNT(PersonID)
FROM Person 
WHERE Location = "New York"