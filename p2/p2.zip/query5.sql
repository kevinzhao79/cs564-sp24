SELECT COUNT(PersonID)
FROM Person 
WHERE Rating > 1000 
AND NumItemsSelling > 0;